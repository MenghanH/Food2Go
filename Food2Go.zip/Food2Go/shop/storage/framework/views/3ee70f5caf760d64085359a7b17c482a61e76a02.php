<div id="footer" class="color-div">
		<div class="container">
			<div class="row">
				
				<div class="col-sm-2">
					<div class="widget">
						<h4 class="widget-title"></h4>
						<div>
							<!-- <ul>
								<li><a href="blog_fullwidth_2col.html"><i class="fa fa-chevron-right"></i> Web Design</a></li>
								<li><a href="blog_fullwidth_2col.html"><i class="fa fa-chevron-right"></i> Web development</a></li>
								<li><a href="blog_fullwidth_2col.html"><i class="fa fa-chevron-right"></i> Marketing</a></li>
								<li><a href="blog_fullwidth_2col.html"><i class="fa fa-chevron-right"></i> Tips</a></li>
								<li><a href="blog_fullwidth_2col.html"><i class="fa fa-chevron-right"></i> Resources</a></li>
								<li><a href="blog_fullwidth_2col.html"><i class="fa fa-chevron-right"></i> Illustrations</a></li>
							</ul> -->
						</div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="contact-info">
				
					</div>
				</div>
				<div class="col-sm-4">
				 <div class="col-sm-10">
					<div class="widget">
						<h4 class="widget-title">Contact Us</h4>
						<div>
							<div class="contact-info">
								<i class="fa fa-map-marker"></i>
								<p><a href="<?php echo e(route('contact')); ?>">17 Wakefield, Auckland CBD </a>Phone: +64 204 103 8599</p>
								<p>Next to the Imart supermarket and opposite the AUT university</p>
							</div>
						</div>
					</div>
				  </div>
				</div>
				
			</div> <!-- .row -->
		</div> <!-- .container -->
</div> <!-- #footer -->
