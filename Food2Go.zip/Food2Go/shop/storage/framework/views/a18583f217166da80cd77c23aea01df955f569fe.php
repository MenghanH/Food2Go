<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1><?php echo e($msg); ?></h1>
</body>
</html>