<?php $__env->startSection('content'); ?>
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Add product</h6>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb">
					<a href="<?php echo e(route('trang-chu')); ?>">Home</a> / <span>Adding</span>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	
	<div class="container">
		<div id="content">
			
			<form action="<?php echo e(route('add')); ?>" method="post" enctype="multipart/form-data" class="beta-form-checkout">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<div class="row">
					<div class="col-sm-3"></div>
					<?php if(count($errors)>0): ?>
						<div class="alert alert-danger">
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php echo e($err); ?>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					<?php endif; ?>
					<?php if(Session::has('flag')): ?>
						<div class="alert alert-<?php echo e(Session::get('flag')); ?>"><?php echo e(Session::get('message')); ?></div>
					<?php endif; ?>
					<div class="col-sm-6">
						<h4>Add product</h4>
						<div class="space20">&nbsp;</div>

						
						<div class="form-block">
							<label for="product">Product Name*</label>
							<input type="text" name="name" required>
						</div>

						<div class="form-block">
							<label for="your_last_name">Id Type*</label>
							<input type="text" name="id_type" required>
						</div>

						<div class="form-block">
							<label for="description">Description*</label>
							<input type="text" name="description" required>
						</div>

						<div class="form-block">
							<label for="unit-price">Unit price*</label>
							<input type="text" name="unit_price" required>
						</div>
						<div class="form-block">
							<label for="promotion-price">Promotion price*</label>
							<input type="text" name="promotion_price" >
						</div>
						<div class="form-block">
							<label for="image">Image*</label>
							<input type="file" name="image" required>

						</div>
						<div class="form-block">
							<label for="unit">Unit*</label>
							<input type="text" name="unit" required>
						</div>
						<div class="form-block">
							<label for="new">New*</label>
							<input type="text" name="new" required>
						</div>
						<div class="form-block">
							<button type="submit" class="btn btn-primary">Add</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</form>
		</div> <!-- #content -->
	</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>