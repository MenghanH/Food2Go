<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div>
	<h3>User Name: <h4><?php echo e($name); ?></h4></h3>
	<h3>User Email: <h4><?php echo e($email); ?></h4></h3>
	<h3>Subject: <h4><?php echo e($subject); ?></h4></h3>
	<h3>Message: </h3>
	<p><?php echo e($msg); ?></p>
</div>
</body>
</html>