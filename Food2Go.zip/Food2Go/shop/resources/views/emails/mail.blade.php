<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div>
	<h3>User Name: <h4>{{$name}}</h4></h3>
	<h3>User Email: <h4>{{$email}}</h4></h3>
	<h3>Subject: <h4>{{$subject}}</h4></h3>
	<h3>Message: </h3>
	<p>{{$msg}}</p>
</div>
</body>
</html>